<?php
/**
 * BP REST: BP_REST_Attachments_Group_Avatar_Endpoint class
 *
 * @package BuddyPress
 * @deprecated 6.0.0
 */

defined( 'ABSPATH' ) || exit;

_deprecated_file( basename( __FILE__ ), '6.0.0', 'bp-groups/classes/class-bp-rest-attachments-group-avatar-endpoint.php' );

/** BP_REST_Attachments_Group_Avatar_Endpoint class */
require_once trailingslashit( constant( 'BP_PLUGIN_DIR' ) . constant( 'BP_SOURCE_SUBDIRECTORY' ) ) . 'bp-groups/classes/class-bp-rest-attachments-group-avatar-endpoint.php';
