<?php
/**
 * Email Body
 *
 * @author 		RestroPress
 * @package 	RestroPress/Templates/Emails
 * @version     2.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// {email} is replaced by the content entered in RestroPress > Settings > Emails

?>
{email}
