<?php
$color = rpress_get_option( 'checkout_color', 'red' );
?>
<!-- Start Bootstrap Modal -->
<div class="modal fade " id="rpressImageModal" tabindex="-1" role="dialog" aria-labelledby="rpressImageModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <img src="" class="imagepreview" style="width: 100%;" >
      </div>
    </div>
  </div>
</div>
<!-- End Bootstrap Modal -->