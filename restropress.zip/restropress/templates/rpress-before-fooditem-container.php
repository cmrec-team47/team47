<div class="rpress_fooditems_list rp-col-lg-6 rp-col-md-6 rp-col-sm-9 rp-col-xs-12">
